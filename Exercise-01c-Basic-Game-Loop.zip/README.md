# Exercise-01c-Basic-Game-Loop

Exercise for MSCH-C220

A simple version of a game loop, designed to navigate an interactive fiction world (contained in a dictionary), implemented in Python.

## Implementation
Created using Python 3.8

## References
[Zork, 1977 by Tim Anderson, Marc Blank, Dave Lebling, and Bruce Daniels](https://en.wikipedia.org/wiki/Zork)

## Future Development
None

## Created by
Edison Li